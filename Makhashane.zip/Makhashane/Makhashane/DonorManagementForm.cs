﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Makhashane
{
    public partial class DonorManagementForm : Form
    {
        private List<Donor> donors = new List<Donor>();
        public class Donor
        {
            public string DonorName { get; set; }
            public string Email { get; set; }
            public string PhoneNumber { get; set; }
            public string Address { get; set; }
        }
        public DonorManagementForm()
        {
            InitializeComponent();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DonorManagementForm donorManagementForm = new DonorManagementForm();
            donorManagementForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VolunteerManagementForm volunteerManagementForm = new VolunteerManagementForm();
            volunteerManagementForm.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ProgramManagementForm programManagementForm = new ProgramManagementForm();
            programManagementForm.Show();
            this.Hide();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            ClientManagementForm clientManagementForm = new ClientManagementForm();
            clientManagementForm.Show();
            this.Hide();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            ReportingandAnalyticsForm reportingandAnalyticsForm = new ReportingandAnalyticsForm();
            reportingandAnalyticsForm.Show();
            this.Hide();
        }

        private void DonorManagementForm_Load(object sender, EventArgs e)
        {
            donors.Add(new Donor
            {
                DonorName = "Michael Johnson",
                Email = "michael.johnson@example.com",
                PhoneNumber = "555-789-0123",
                Address = "789 Elm St, City, Country"
            });
            donors.Add(new Donor
            {
                DonorName = "Sarah Lee",
                Email = "sarah.lee@example.com",
                PhoneNumber = "555-234-5678",
                Address = "101 Pine St, City, Country"
            });

            RefreshDonorList();
        }
        private void RefreshDonorList()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = donors;
        }

        private void attaddbtn_Click(object sender, EventArgs e)
        {
            Donor newDonor = new Donor
            {
                DonorName = attname.Text,
                Email = dob.Text,
                PhoneNumber = number.Text,
                Address = textBox1.Text
            };

            donors.Add(newDonor);
            RefreshDonorList();
        }

        private void atteditbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                donors[index].DonorName = attname.Text;
                donors[index].Email = dob.Text;
                donors[index].PhoneNumber = number.Text;
                donors[index].Address = textBox1.Text;
                RefreshDonorList();
            }
        }

        private void attdelbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                donors.RemoveAt(index);
                RefreshDonorList();
            }
        }
    }
}
