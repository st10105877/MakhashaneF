﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Makhashane
{
    public partial class ReportingandAnalyticsForm : Form
    {
        private List<Client> clients = new List<Client>();
        private List<Volunteer> volunteers = new List<Volunteer>();

        public class Client
        {
            public string ClientName { get; set; }
            public string Email { get; set; }
        }


        public class Volunteer
        {
            public string Name { get; set; }
            public string Skills { get; set; }
        }
        public ReportingandAnalyticsForm()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReportingandAnalyticsForm reportingandAnalyticsForm = new ReportingandAnalyticsForm();
            reportingandAnalyticsForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VolunteerManagementForm volunteerManagementForm = new VolunteerManagementForm();
            volunteerManagementForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DonorManagementForm donorManagementForm = new DonorManagementForm();
            donorManagementForm.Show();
                this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProgramManagementForm programManagementForm = new ProgramManagementForm();
            programManagementForm.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClientManagementForm clientManagementForm = new ClientManagementForm();
            clientManagementForm.Show();
            this.Hide();
        }

        private void ReportingandAnalyticsForm_Load(object sender, EventArgs e)
        {
            clients.Add(new Client { ClientName = "John Doe", Email = "john.doe@example.com" });
            clients.Add(new Client { ClientName = "Jane Smith", Email = "jane.smith@example.com" });

            volunteers.Add(new Volunteer { Name = "Michael Johnson", Skills = "Teaching" });
            volunteers.Add(new Volunteer { Name = "Sarah Lee", Skills = "Healthcare" });

            // Populate ComboBox with Clients (you may add a separate ComboBox for Volunteers if needed)
            comboBox1.DataSource = clients;
            comboBox1.DisplayMember = "ClientName"; // Shows only the ClientName// Default to "Donations"
        }
        private List<List<string>> GenerateReport(DateTime startDate, DateTime endDate, Client client, string volunteerInput, string reportType)
        {
            List<List<string>> reportData = new List<List<string>>();

            // Add the header row
            List<string> headerRow = new List<string>
            {
                "Report Type", "Start Date", "End Date", "Client", "Volunteer", "Report Content"
            };
            reportData.Add(headerRow);

            // Add the data row
            List<string> dataRow = new List<string>
            {
                reportType,
                startDate.ToShortDateString(),
                endDate.ToShortDateString(),
                client != null ? client.ClientName : "All clients",
                !string.IsNullOrEmpty(volunteerInput) ? volunteerInput : "Not specified",
                "This section will contain data based on the selected report type..."
            };
            reportData.Add(dataRow);

            return reportData;
        }


        private void button6_Click(object sender, EventArgs e)
        {
            DateTime startDate = dateTimePicker2.Value;
            DateTime endDate = dateTimePicker1.Value;

            // Get selected client from comboBox1
            Client selectedClient = comboBox1.SelectedItem as Client;

            // Get volunteer input from textBox2
            string volunteerInput = textBox2.Text;

            // Get report type from comboBox1
            string reportType = comboBox1.SelectedItem.ToString();

            // Generate the report data
            List<List<string>> reportData = GenerateReport(startDate, endDate, selectedClient, volunteerInput, reportType);

            // Set the DataGridView columns (you can adjust the column names as needed)
            dataGridView1.Columns.Clear();  // Clear existing columns
            dataGridView1.Rows.Clear();  // Clear existing rows

            // Create columns based on the header
            foreach (var header in reportData[0])
            {
                dataGridView1.Columns.Add(header, header);
            }

            // Add rows to the DataGridView
            foreach (var row in reportData.Skip(1))
            {
                dataGridView1.Rows.Add(row.ToArray());
            }
        }
    
    }
}
