﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Makhashane.ProgramManagementForm;

namespace Makhashane
{
    public partial class ProgramManagementForm : Form
    {
        private List<Program> programs = new List<Program>();
        public class Program
        {
            public string Name { get; set; }
            public string Description { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
        }
        public ProgramManagementForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProgramManagementForm programManagementForm = new ProgramManagementForm();
            programManagementForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VolunteerManagementForm volunteerManagementForm = new VolunteerManagementForm();
            volunteerManagementForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DonorManagementForm donorManagementForm = new DonorManagementForm();
            donorManagementForm.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClientManagementForm clientManagementForm = new ClientManagementForm(); 
                clientManagementForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReportingandAnalyticsForm reportingandAnalyticsForm = new ReportingandAnalyticsForm();
                reportingandAnalyticsForm.Show();
            this.Hide();
        }

        private void ProgramManagementForm_Load(object sender, EventArgs e)
        {
            programs.Add(new Program
            {
                Name = "Education Program",
                Description = "A program aimed at providing educational resources to underprivileged children.",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddMonths(6)
            });
            programs.Add(new Program
            {
                Name = "Health Program",
                Description = "A program focusing on healthcare and wellness for underserved communities.",
                StartDate = DateTime.Now.AddMonths(1),
                EndDate = DateTime.Now.AddMonths(7)
            });

            RefreshProgramList();
        }
        private void RefreshProgramList()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = programs;
        }

        private void attdelbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                programs.RemoveAt(index);
                RefreshProgramList();
            }
        }

        private void atteditbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                programs[index].Name = attname.Text;
                programs[index].Description = dob.Text;
                programs[index].StartDate = dateTimePicker1.Value;
                programs[index].EndDate = dateTimePicker2.Value;
                RefreshProgramList();
            }
        }

        private void attaddbtn_Click(object sender, EventArgs e)
        {
            Program newProgram = new Program
            {
                Name = attname.Text,
                Description = dob.Text,
                StartDate = dateTimePicker1.Value,
                EndDate = dateTimePicker2.Value
            };

            programs.Add(newProgram);
            RefreshProgramList();
        }
    }
}
