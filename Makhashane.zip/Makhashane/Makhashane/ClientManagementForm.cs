﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Makhashane
{
    public partial class ClientManagementForm : Form
    {
        private List<Client> clients = new List<Client>();

        public class Client
        {
            public string ClientName { get; set; }
            public string Email { get; set; }
            public string PhoneNumber { get; set; }
            public string Address { get; set; }
            public DateTime IntakeDate { get; set; }
        }
        public ClientManagementForm()
        {
            InitializeComponent();
        }


        private void button5_Click(object sender, EventArgs e)
        {
            ClientManagementForm clientManagementForm = new ClientManagementForm();
            clientManagementForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VolunteerManagementForm volunteerManagementForm = new VolunteerManagementForm();
            volunteerManagementForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DonorManagementForm donorManagementForm = new DonorManagementForm();
            donorManagementForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProgramManagementForm programManagementForm = new ProgramManagementForm();
            programManagementForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReportingandAnalyticsForm reportingandAnalyticsForm = new ReportingandAnalyticsForm();
            reportingandAnalyticsForm.Show();
            this.Hide();
        }

        private void ClientManagementForm_Load(object sender, EventArgs e)
        {
            clients.Add(new Client
            {
                ClientName = "John Doe",
                Email = "john.doe@example.com",
                PhoneNumber = "555-123-4567",
                Address = "123 Main St, City, Country",
                IntakeDate = DateTime.Now
            });
            clients.Add(new Client
            {
                ClientName = "Jane Smith",
                Email = "jane.smith@example.com",
                PhoneNumber = "555-987-6543",
                Address = "456 Oak St, City, Country",
                IntakeDate = DateTime.Now.AddDays(-10)
            });

            RefreshClientList();
        }
        private void RefreshClientList()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = clients;
        }

        private void attaddbtn_Click(object sender, EventArgs e)
        {
            Client newClient = new Client
            {
                ClientName = attname.Text,
                Email = dob.Text,
                PhoneNumber = number.Text,
                Address = textBox2.Text,
                IntakeDate = dateTimePicker2.Value
            };

            clients.Add(newClient);
            RefreshClientList();
        }

        private void atteditbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                clients[index].ClientName = attname.Text;
                clients[index].Email = dob.Text;
                clients[index].PhoneNumber = number.Text;
                clients[index].Address = textBox2.Text;
                clients[index].IntakeDate = dateTimePicker2.Value;
                RefreshClientList();
            }
        }

        private void attdelbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                clients.RemoveAt(index);
                RefreshClientList();
            }
        }
    }
}
