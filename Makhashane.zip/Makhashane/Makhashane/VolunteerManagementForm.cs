﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Makhashane
{
    public partial class VolunteerManagementForm : Form
    {
        private List<Volunteer> volunteers = new List<Volunteer>();
        public class Volunteer
        {
            public string Name { get; set; }
            public string Email { get; set; }
            public string PhoneNumber { get; set; }
            public string Skills { get; set; }
            public string Availability { get; set; }
        }
        public VolunteerManagementForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VolunteerManagementForm volunteerManagementForm = new VolunteerManagementForm();
            volunteerManagementForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DonorManagementForm donorManagementForm = new DonorManagementForm();
            donorManagementForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProgramManagementForm programManagementForm = new ProgramManagementForm();
            programManagementForm.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClientManagementForm clientManagementForm = new ClientManagementForm(); 
            clientManagementForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReportingandAnalyticsForm reportingandAnalyticsForm = new ReportingandAnalyticsForm();
            reportingandAnalyticsForm.Show();
            this.Hide();
        }

        private void VolunteerManagementForm_Load(object sender, EventArgs e)
        {
            // Initialize with sample volunteer data
            volunteers.Add(new Volunteer
            {
                Name = "Alice Green",
                Email = "alice@vol.com",
                PhoneNumber = "123-456-7890",
                Skills = "Teaching, Mentorship",
                Availability = "Weekends"
            });
            volunteers.Add(new Volunteer
            {
                Name = "Bob White",
                Email = "bob@vol.com",
                PhoneNumber = "987-654-3210",
                Skills = "Healthcare, Counseling",
                Availability = "Weekdays"
            });

            RefreshVolunteerList();
        }
        private void RefreshVolunteerList()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = volunteers;
        }

        private void attaddbtn_Click(object sender, EventArgs e)
        {
            Volunteer newVolunteer = new Volunteer
            {
                Name = attname.Text,
                Email = dob.Text,
                PhoneNumber = number.Text,
                Skills = textBox2.Text,
                Availability = textBox1.Text
            };

            volunteers.Add(newVolunteer);
            RefreshVolunteerList();
        }

        private void atteditbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                volunteers[index].Name = attname.Text;
                volunteers[index].Email = dob.Text;
                volunteers[index].PhoneNumber = number.Text;
                volunteers[index].Skills = textBox2.Text;
                volunteers[index].Availability = textBox1.Text;
                RefreshVolunteerList();
            }
        }

        private void attdelbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int index = dataGridView1.SelectedRows[0].Index;
                volunteers.RemoveAt(index);
                RefreshVolunteerList();
            }
        }
    }
}
