Masakhane Foundation Application
This is a desktop application developed for Masakhane Foundation. The purpose of this application is to streamline the organization's operations, including managing donors, volunteers, programs, and client information, while improving reporting and analytics. This application provides an easy-to-use interface to help manage day-to-day tasks efficiently.


Open the Project in Visual Studio
Launch Visual Studio.
Go to File > Open > Project/Solution.
Navigate to the folder where you cloned or extracted the project.
Open the solution file (.sln) for the project. This will load the entire project in Visual Studio.
3. Build the Project
Once the project is open in Visual Studio, you can build the project:

In Visual Studio, go to the Build menu.

Select Build Solution (or press Ctrl+Shift+B).

This will compile the application and check for any errors. If the project compiles successfully, you'll see Build Succeeded in the output window.

4. Run the Application
After the project has successfully built, you can run it:

Start the application by clicking on Debug > Start Without Debugging (or press Ctrl+F5).

This will launch the application without debugging mode, which is suitable for running the final version.
Alternatively, you can click Start Debugging (or press F5) if you want to run the application and debug it (with breakpoints and step-by-step debugging).

Visual Studio will now build the project again if necessary, and the Masakhane Foundation Application will open.

Once the application is running:
	a home page will appear then you will have to login to continue.
	The username= Mukona and password= 12234
	You have to choose admin as role as the user role is not implemented
	

Thereafter you will have access to the following Features:

Donor Management

Track donor information (name, email, phone number, address).
Record donations and generate receipts.
Send personalized reports and updates to donors.
Volunteer Management

Manage volunteer details (name, email, phone, skills, availability).
Track volunteer hours and their involvement in programs.
Program Management

Add and manage program details (name, description, start date, end date).
Track program progress and outcomes.
Client Management

Maintain client information (name, email, phone number, address).
Track client intake and services provided.
Reporting

Generate reports based on client, volunteer, date range, and report type (e.g., Donations, Volunteer Hours, Program Impact).
Installation Instructions
Prerequisites


How to Use
1. Start the Application
Once the application is running, you will see the main dashboard with the following features:

Donor Management
Volunteer Management
Program Management
Client Management
Reporting
2. Entering Information
For each section (Donor, Volunteer, Program, Client, and Reporting), the following forms are available:

Donor Management: Allows you to enter donor information, track donations, and manage communication.
Volunteer Management: Enter volunteer details, track skills and availability.
Program Management: Manage program details like program name, description, and dates.
Client Management: Enter and track client information, intake details, and services provided.
Reporting: Generate reports based on selected filters (e.g., date range, client, volunteer, report type).
For Reporting:

Select a Start Date and End Date using the DateTimePicker controls.
Enter the Client Name and Volunteer Name (as text) in the corresponding TextBox fields.
Choose the Report Type from the ComboBox (e.g., "Donations", "Volunteer Hours").
Click Generate Report to create the report.
3. Generating Reports
The report will be displayed in a MessageBox with details based on your selection, including:

Report Type
Date Range
Client and Volunteer Names
Simulated Data based on the selected report type (e.g., donations, volunteer hours).
Technologies Used
C#: The application is developed using C# and Windows Forms for the UI.
.NET 5.0 (or later): The application uses .NET for building and running the application on Windows.
Windows Forms: UI framework for building the desktop application.
Contributing
Fork the repository and create your own branch.
Make your changes (fix bugs, add features, improve UI).
Commit your changes with a meaningful commit message.
Push your changes to your forked repository.
Create a Pull Request to contribute your changes.
License
This project is licensed under the MIT License - see the LICENSE.md file for details.

